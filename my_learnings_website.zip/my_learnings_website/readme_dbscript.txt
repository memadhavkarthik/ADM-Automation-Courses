--To create a database , run the below codes in mysql 
--To connect with database you have created, update your mysql credentials in mysql_credentials.xlsx


-- Create the database
CREATE DATABASE IF NOT EXISTS my_database1;
USE my_database1;


-- Create the courses table
CREATE TABLE courses (
    courseid VARCHAR(255) PRIMARY KEY,
    coursename VARCHAR(255),
    courselink VARCHAR(255),
    learningtype varchar(255),
    vendorname varchar(255),
    remarks TEXT
);


INSERT INTO courses (courseid, coursename, courselink,learningtype,vendorname)
VALUES
('4851218', 'PowerAutomate', 'https://COGNIZANTLEARNING.sumtotal.host/core/pillarRedirect?relyingParty=LM&url=app%2Fmanagement%2FLMS_ActDetails.aspx%3FActivityId%3D1999126%26UserMode%3D0','Internal','Udemy for Business'),
('4510964', 'Datadog', 'https://COGNIZANTLEARNING.sumtotal.host/core/pillarRedirect?relyingParty=LM&url=app%2Fmanagement%2FLMS_ActDetails.aspx%3FActivityId%3D1855554%26UserMode%3D0','Internal','Udemy for Business'),
('3685672', 'AA360', 'https://COGNIZANTLEARNING.sumtotal.host/core/pillarRedirect?relyingParty=LM&url=app%2Fmanagement%2FLMS_ActDetails.aspx%3FActivityId%3D1703218%26UserMode%3D0','Internal','Udemy for Business'),
('3115680', 'Powershell', 'https://COGNIZANTLEARNING.sumtotal.host/core/pillarRedirect?relyingParty=LM&url=app%2Fmanagement%2FLMS_ActDetails.aspx%3FActivityId%3D1949744%26UserMode%3D0','Internal','Udemy for Business'),
('1872032', 'Snow', 'https://COGNIZANTLEARNING.sumtotal.host/core/pillarRedirect?relyingParty=LM&url=app%2Fmanagement%2FLMS_ActDetails.aspx%3FActivityId%3D1129297%26UserMode%3D0','Internal','Udemy for Business'),
('567828', 'Python', 'https://COGNIZANTLEARNING.sumtotal.host/core/pillarRedirect?relyingParty=LM&url=app%2Fmanagement%2FLMS_ActDetails.aspx%3FActivityId%3D1126820%26UserMode%3D0','Internal','Udemy for Business'),
('EXCE08102021_2', 'Resolve', 'https://COGNIZANTLEARNING.sumtotal.host/core/pillarRedirect?relyingParty=LM&url=app%2Fmanagement%2FLMS_ActDetails.aspx%3FActivityId%3D1772489%26UserMode%3D0','Internal','Cognizant Academy'),
('EXCE638', 'Uipath', 'https://COGNIZANTLEARNING.sumtotal.host/core/pillarRedirect?relyingParty=LM&url=app%2Fmanagement%2FLMS_ActDetails.aspx%3FActivityId%3D839203%26UserMode%3D0','External','UiPath Academy'),
('ELRNG01628', 'Moogsoft', 'https://COGNIZANTLEARNING.sumtotal.host/core/pillarRedirect?relyingParty=LM&url=app%2Fmanagement%2FLMS_ActDetails.aspx%3FActivityId%3D2003216%26UserMode%3D0','Internal','Cognizant Academy'),
('CTHIS318136', 'Dynatrace', 'https://cognizantlearning.sumtotal.host/core/pillarRedirect?relyingParty=LM&url=app%2Fmanagement%2FLMS_ActDetails.aspx%3FActivityId%3D1997565%26UserMode%3D0','Internal','Cognizant Academy');



