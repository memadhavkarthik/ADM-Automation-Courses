from flask import Flask, render_template
import mysql.connector
import pandas as pd

application = Flask(__name__)

# Read MySQL credentials from Excel file
try:
    credentials_df = pd.read_excel('mysql_credentials.xlsx')
    host1 = credentials_df.iloc[0]['Host']
    user1 = credentials_df.iloc[0]['User']
    password1 = credentials_df.iloc[0]['Password']
    database1 = credentials_df.iloc[0]['Database']
except Exception as e:
    print(f"Error reading MySQL credentials from Excel file: {e}")
    host1 = ''
    user1 = ''
    password1 = ''
    database1 = ''

try:
    # Connect to MySQL database
    mydb = mysql.connector.connect(
        host=host1,
        user=user1,
        password=password1,
        database=database1
    )
except mysql.connector.Error as err:
    print(f"Error connecting to MySQL database: {err}")
    mydb = None

@application.route('/')
def display_table():
    if mydb is None:
        return "Error connecting to database. Please check the connection."

    try:
        mycursor = mydb.cursor(dictionary=True)  # Set dictionary=True to fetch results as dictionaries

        query = "SELECT courses.courseid, courses.coursename, courses.courselink, courses.remarks,courses.learningtype, courses.vendorname  FROM courses"
        mycursor.execute(query)
        data = mycursor.fetchall()

        # Close the cursor after fetching results
        mycursor.close()

        # Enumerate the data before passing it to the template
        enumerated_data = [(index + 1, row) for index, row in enumerate(data)]

        return render_template('home.html', course_list=enumerated_data)  # Pass enumerated data as course_list to the template
    except mysql.connector.Error as err:
        print(f"Error executing MySQL query: {err}")
        return "Error fetching data from database. Please try again later."

if __name__ == '__main__':
    application.run(host='0.0.0.0', debug=True)
